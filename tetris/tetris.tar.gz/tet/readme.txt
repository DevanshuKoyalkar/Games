Instructions-
"a" is for clockwise rotation and "s" is for ACW rotation
down right and left movements are done by respective arrow keys
spacebar is used for dropping instantly

